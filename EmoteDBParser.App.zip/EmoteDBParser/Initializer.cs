﻿using CUE4Parse.Encryption.Aes;
using CUE4Parse.FileProvider;
using CUE4Parse.UE4.Assets.Exports.Texture;
using CUE4Parse.UE4.Localization;
using CUE4Parse.UE4.Objects.Core.Misc;
using CUE4Parse.UE4.Readers;
using CUE4Parse.UE4.Versions;
using CUE4Parse_Conversion.Textures;
using EmoteDBParser;
using Newtonsoft.Json;

public class ExportResult
{
    public string LocresJsonPath { get; set; } = "";
    public string UassetPath { get; set; } = "";
    public string UexpPath { get; set; } = "";
}

/// <summary>
/// Loads a PUBG pak archive, extracts the EmoteDB data table + localization,
/// parses every emote row and (best-effort) exports each emote's UI icon as a
/// PNG so a UI layer can render it directly, without needing to keep the
/// CUE4Parse provider alive.
/// </summary>
public static class Initializer
{
    // NOTE: this key is specific to the public PUBG build this tool targets.
    // If parsing fails with an "invalid AES key" style error, the game has
    // likely rotated its key and this value needs to be updated.
    private const string AesKeyHex =
        "0x3435444431354436444432444135304145423731434537413532383443463845";

    private const string LocresPath =
        "TslGame/Content/Localization/TSL_Item/en/TSL_Item.locres";

    private const string EmoteDbUassetPath =
        "TslGame/Content/Animations/Battlegrounds/Anims/Emotes/EmoteDB.uasset";

    /// <summary>
    /// Runs the full pipeline: initialize the file provider, export the
    /// localization table + EmoteDB data table, parse every emote row, and
    /// export each row's icon texture as a PNG next to the parsed data.
    /// </summary>
    /// <param name="pakDirectory">Folder containing the game's .pak/.utoc/.ucas files.</param>
    /// <param name="outputDirectory">
    /// Scratch/output directory the caller controls the lifetime of (e.g. a
    /// temp folder that gets deleted when the UI closes).
    /// </param>
    /// <param name="progress">Optional progress/status reporter for a UI.</param>
    /// <param name="cancellationToken">Optional cancellation token.</param>
    public static List<EmoteRow> ExportPubgAssets(
        string pakDirectory,
        string outputDirectory,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        if (!Directory.Exists(pakDirectory))
            throw new DirectoryNotFoundException($"Pak directory not found: {pakDirectory}");

        progress?.Report("Initializing file provider...");

        using var provider = new DefaultFileProvider(
            pakDirectory,
            SearchOption.AllDirectories,
            new VersionContainer(EGame.GAME_PlayerUnknownsBattlegrounds)
        );

        provider.Initialize();

        var aesKey = new FAesKey(AesKeyHex);
        provider.SubmitKey(new FGuid(), aesKey);

        cancellationToken.ThrowIfCancellationRequested();

        Directory.CreateDirectory(outputDirectory);

        var result = new ExportResult();

        // ---- 1. Export the .locres file as JSON ----
        progress?.Report("Exporting localization table...");

        if (provider.TryGetGameFile(LocresPath, out var locresFile))
        {
            var locresData = locresFile.Read();
            var locres = new FTextLocalizationResource(new FByteArchive(LocresPath, locresData));

            string locresJson = JsonConvert.SerializeObject(locres, Formatting.Indented);
            string locresJsonPath = Path.Combine(outputDirectory, "TSL_Item.locres.json");
            File.WriteAllText(locresJsonPath, locresJson);

            result.LocresJsonPath = locresJsonPath;
        }
        else
        {
            throw new FileNotFoundException($"Could not find {LocresPath} in provider");
        }

        cancellationToken.ThrowIfCancellationRequested();

        // ---- 2. Export the .uasset/.uexp pair as raw files ----
        progress?.Report("Exporting EmoteDB data table...");

        if (provider.TryGetGameFile(EmoteDbUassetPath, out _))
        {
            if (provider.TrySavePackage(EmoteDbUassetPath, out var savedFiles))
            {
                foreach (var (path, data) in savedFiles)
                {
                    string outPath = Path.Combine(outputDirectory, Path.GetFileName(path));
                    File.WriteAllBytes(outPath, data);

                    if (path.EndsWith(".uasset"))
                        result.UassetPath = outPath;
                    else if (path.EndsWith(".uexp"))
                        result.UexpPath = outPath;
                }
            }
        }
        else
        {
            throw new FileNotFoundException($"Could not find {EmoteDbUassetPath} in provider");
        }

        if (string.IsNullOrEmpty(result.UassetPath) || string.IsNullOrEmpty(result.UexpPath))
            throw new InvalidDataException("Failed to export EmoteDB .uasset/.uexp pair.");

        cancellationToken.ThrowIfCancellationRequested();

        // ---- 3. Parse every emote row out of the data table ----
        progress?.Report("Parsing emote rows...");

        string parsedJsonPath = Path.Combine(outputDirectory, "EmoteDB.json");

        var rows = Parser.Parse(
            result.UassetPath,
            result.UexpPath,
            parsedJsonPath,
            result.LocresJsonPath
        );

        cancellationToken.ThrowIfCancellationRequested();

        // ---- 4. Best-effort: export each row's icon texture as a PNG ----
        progress?.Report($"Exporting icons for {rows.Count} emotes...");

        string iconsDirectory = Path.Combine(outputDirectory, "Icons");
        Directory.CreateDirectory(iconsDirectory);

        int done = 0;
        int succeeded = 0;
        var failureReasons = new Dictionary<string, List<int>>();

        foreach (var row in rows)
        {
            cancellationToken.ThrowIfCancellationRequested();

            if (string.IsNullOrWhiteSpace(row.Icon))
            {
                Note(failureReasons, "no icon path on row", row.Id);
            }
            else
            {
                var (path, failureReason) = TryExportIconPng(provider, row.Icon, iconsDirectory);
                row.IconImagePath = path;

                if (path != null)
                    succeeded++;
                else
                    Note(failureReasons, failureReason ?? "unknown", row.Id);
            }

            done++;

            if (done % 5 == 0 || done == rows.Count)
                progress?.Report($"Exporting icons... ({done}/{rows.Count})");
        }

        Console.WriteLine($"Icon export: {succeeded}/{rows.Count} succeeded.");

        foreach (var (reason, ids) in failureReasons.OrderByDescending(kv => kv.Value.Count))
        {
            string sample = string.Join(", ", ids.Take(10));
            string more = ids.Count > 10 ? $" (+{ids.Count - 10} more)" : "";

            Console.WriteLine($"  {ids.Count}x \"{reason}\" - rows: {sample}{more}");
        }

        progress?.Report("Done.");

        return rows;
    }

    private static void Note(Dictionary<string, List<int>> failureReasons, string reason, int rowId)
    {
        if (!failureReasons.TryGetValue(reason, out var ids))
        {
            ids = new List<int>();
            failureReasons[reason] = ids;
        }

        ids.Add(rowId);
    }

    /// <summary>
    /// Attempts to decode a UTexture2D at <paramref name="iconAssetPath"/> and
    /// save it as a PNG. Never throws - returns a human-readable failure
    /// reason instead, so the caller can report *why* an icon didn't export
    /// rather than silently dropping it.
    /// </summary>
    private static (string? Path, string? FailureReason) TryExportIconPng(
        DefaultFileProvider provider,
        string? iconAssetPath,
        string outputDirectory)
    {
        if (string.IsNullOrWhiteSpace(iconAssetPath))
            return (null, "no icon path on row");

        try
        {
            if (!provider.TryGetGameFile(iconAssetPath, out _))
                return (null, "asset file not found in mounted paks");

            if (!provider.TryLoadPackageObject<UTexture2D>(iconAssetPath, out var texture) || texture == null)
                return (null, "package loaded but no UTexture2D export with that name");

            var decoded = texture.Decode(ETexturePlatform.DesktopMobile);

            if (decoded == null)
                return (null, $"Decode() returned null (pixel format: {texture.Format})");

            // CTexture holds raw decoded pixel data; Encode() does the
            // PNG conversion for us and returns the file extension to use.
            var imageData = decoded.Encode(ETextureFormat.Png, false, out var ext);

            if (imageData.Length == 0)
                return (null, "Encode() returned empty data");

            string fileName = SanitizeFileName(Path.GetFileNameWithoutExtension(iconAssetPath)) + "." + ext;
            string outPath = Path.Combine(outputDirectory, fileName);

            File.WriteAllBytes(outPath, imageData);

            return (outPath, null);
        }
        catch (Exception ex)
        {
            // Icon export is best-effort; a decode/version mismatch for a
            // single texture shouldn't fail the whole load.
            return (null, $"{ex.GetType().Name}: {ex.Message}");
        }
    }

    private static string SanitizeFileName(string name)
    {
        foreach (char c in Path.GetInvalidFileNameChars())
            name = name.Replace(c, '_');

        return name;
    }
}